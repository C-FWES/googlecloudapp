# an object of WSGI application
import os.path

from flask import Flask, render_template, request, current_app, send_from_directory, send_file
from werkzeug.utils import secure_filename

app = Flask(__name__)  # Flask constructor
app.static_folder = 'static'
UPLOAD_FOLDER = 'Files'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


# A decorator used to tell the application
# which URL is associated function
@app.route('/')
def form():
    return render_template('upload.html')


@app.route('/submitted', methods=['GET', 'POST'])
def submit():
    if request.method == 'POST':
        f = request.files['file']
        f.save('Files/' + f.filename)
        file_obj = [file for file in os.scandir('Files/')]
        return render_template("upload.html", file_obj=file_obj)


@app.route('/Files/<filename>')
def download(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename, as_attachment=True)


if __name__ == '__main__':
    app.run()
