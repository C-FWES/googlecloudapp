"""
Flask code to initalize a UI interface to retrieve S3 content.
Majority of code was created via instructions found in:

# https://www.geeksforgeeks.org/python-introduction-to-web-development-using-flask/
"""


from cached import CacheView
from flask import Flask, render_template, request, make_response

# create flask constructor and initialize connection to aws
app = Flask(__name__)
s3 = CacheView(log_level='error')


# start page where user will input url
@app.route('/')
def form():
    # cache_input html will post to the /cache url
    return render_template('cache_input.html')


# output page
# TODO: input url into cache url
@app.route('/cache', methods=['POST', 'GET'])
def retrieve():
    if request.method == 'POST':
        # retrieve input submitted in form function and retrueve
        url = request.form['URL']
        result = s3.extract_content(url, outfile=None)
        # if no result result to html that will redirect to live link
        if result is None:
            url_test = url.split('://')
            if url_test[0] not in ['http', 'https']:
                url = 'https://' + url
            return render_template('not_found.html', value=url)
        # if url is a pdf, format the result as such, otherwise return as is to get functioning html/txt page
        if url.split('.')[-1].replace('/', '') == 'pdf':
            result = make_response(result)
            result.headers['Content-Type'] = 'application/pdf'
            result.headers['Content-Disposition'] = 'inline; filename=%s.pdf' % 'cached_pdf'
        return result


# if file is pdf, render template according to doc.html template
@app.route('/<id>')
def show_pdf(id=None):
    if id is not None:
        return render_template('doc.html', doc_id=id)


if __name__ == '__main__':
    app.run(debug=True)
